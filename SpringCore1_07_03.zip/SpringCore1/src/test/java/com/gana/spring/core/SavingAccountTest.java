package com.gana.spring.core;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class SavingAccountTest {
	SavingAccount savingAccount;
	@Before
	public void setUp() throws Exception {
		savingAccount=new SavingAccount("ICICI",500);
	}

/*	@Test
	public void testSavingAccount() {
		fail("Not yet implemented");
	}

	@Test
	public void testSavingAccountStringInt() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeposit() {
		fail("Not yet implemented");
	}*/

	@Test
	public void testWithdraw() {
		
		assertEquals(500, savingAccount.withdraw());
	}

}
