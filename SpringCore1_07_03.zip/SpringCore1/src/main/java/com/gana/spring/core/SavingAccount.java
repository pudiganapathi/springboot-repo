package com.gana.spring.core;

public class SavingAccount implements Account {
	int cash;
	String name;

	public SavingAccount() {
		System.out.println("Inside dedault constructor in SavingAccount");
	}

	SavingAccount(String name,int cash) {
		System.out.println("Inside params constructor in SavingAccount");
		this.cash = cash;
		this.name=name;
	}

	public void deposit(int cash) {
		this.cash=this.cash+cash;
		System.out.println("in deposit SavingAccount");

	}

	public int withdraw() {
		System.out.println("inside withdraw SavingAccount");
		return this.cash;
	}

	public void setCash(int cash) {
		this.cash = cash;
	}

	public void setName(String name) {
		this.name = name;
	}

	
}
