package com.gana.spring.core;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringApp {

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("classpath:/META-INF/spring/app-context.xml");
		
		Customer  ganaCustomer= (Customer) context.getBean("ganaCus");
		ganaCustomer.printBalace();
		
		Customer  rajuCustomer= (Customer) context.getBean("rajuCus");
		rajuCustomer.printBalace();
	}

}
