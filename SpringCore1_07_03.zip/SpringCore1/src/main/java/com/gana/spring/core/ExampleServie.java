package com.gana.spring.core;

public class ExampleServie {
	
	String name;

	public String getMessage() {
		return "Welcome"+name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	
}
