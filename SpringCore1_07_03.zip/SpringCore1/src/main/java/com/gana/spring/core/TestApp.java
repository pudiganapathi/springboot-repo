package com.gana.spring.core;

public class TestApp {
	public static void main(String[] args) {
		Account savingAcc=new SavingAccount("Icici",100);
		Customer c1=new Customer("gana", savingAcc);
		c1.printBalace();
		
	}
}
