package com.gana.spring.core;

public class ChequeBook extends SavingAccount {
	public ChequeBook() {
		System.out.println("Inside dedault constructor ChequeBook");
	}

	ChequeBook(String name,int cash) {
		System.out.println("Inside param constructor ChequeBook");
		this.cash = cash;
		this.name=name;
	}
	@Override
	public int withdraw() {
		System.out.println("inside withdraw ChequeBook");
		return this.cash-100;
	}
	
	void emiLoan() {
		System.out.println("inside emiLoan ChequeBook");
		this.cash=this.cash+100;
	}
}
