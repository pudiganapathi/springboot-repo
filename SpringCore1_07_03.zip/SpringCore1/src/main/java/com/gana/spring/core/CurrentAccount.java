package com.gana.spring.core;

public class CurrentAccount implements Account {
	int cash;
	String name;

	public CurrentAccount() {
		System.out.println("Inside dedault constructor");
	}

	CurrentAccount(String name,int cash) {
		this.cash = cash;
		this.name=name;
	}

	public void deposit(int cash) {
		this.cash=this.cash+cash;
		System.out.println("in deposit CurrentAccount");

	}

	public int withdraw() {
		System.out.println("inside withdraw CurrentAccount");
		if(this.cash>1000);
		return this.cash-1000;
	}

	public void setCash(int cash) {
		this.cash = cash;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
