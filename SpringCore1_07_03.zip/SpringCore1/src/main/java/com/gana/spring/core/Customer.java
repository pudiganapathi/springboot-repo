package com.gana.spring.core;

public class Customer {
	Account account;
	String name;
	
	public Customer() {
		// TODO Auto-generated constructor stub
	}
    public Customer(String name,Account account) {
    	this.name=name;
    	this.account=account;
	}
    void printBalace() {
    	System.out.println(this.account.withdraw());
    }
	public void setAccount(Account account) {
		this.account = account;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
