/**
 * 
 */
package com.gana.spring.core;

/**
 * @author GP
 *
 */
public interface Account {

	void deposit(int cash);
	int withdraw();
	
	
}
