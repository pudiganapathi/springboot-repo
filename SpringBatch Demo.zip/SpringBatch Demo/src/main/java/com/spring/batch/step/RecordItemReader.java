package com.spring.batch.step;

import java.util.List;

import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.batch.item.data.RepositoryItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.spring.batch.model.Record;
import com.spring.batch.repository.RecordRepository;

@Component
@StepScope
public class RecordItemReader extends RepositoryItemReader<Record> {
	@Autowired
	private RecordRepository recordRepository;
	//private RecordRepository recordRepository;
	private int count = 0;
	List<Record> records;
	private String[] messages = { "javainuse.com"};

	/*@Override
	public Record read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		//RecordRepository recordRepository=applicationContext.getBean(RecordRepository.class);
		System.out.println("-------"+recordRepository);
		if (count < messages.length) {
			Record record=new Record();
			record.setFirstName(messages[count++]);
			return record;
		} else {
			count = 0;
		}
		return null;
	}*/

	@Override
	public void afterPropertiesSet() throws Exception {
		setRepository(recordRepository);
		setMethodName("findAll");
		setPageSize(1);
	}
	
}
