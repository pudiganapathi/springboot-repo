package com.spring.batch.repository;

import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.spring.batch.model.Record;

@Repository
@Transactional
@NamedQueries({ @NamedQuery(name = "Record.findAll", query = "SELECT * FROM Record where rowno<=2") })
public interface RecordRepository extends JpaRepository<Record, Long> {

}