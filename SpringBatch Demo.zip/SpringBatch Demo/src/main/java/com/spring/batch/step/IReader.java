package com.spring.batch.step;

import java.util.ArrayList;
import java.util.List;

import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.spring.batch.model.Record;
import com.spring.batch.repository.RecordRepository;

@Component
@StepScope
public class IReader implements ItemReader<Record> {
	@Autowired
	private RecordRepository recordRepository;
	private int count = 0;
	@Override
	public Record read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		List<Record> records=new ArrayList<>();		
		if (count < records.size()) {
			return records.get(0);
		} else {
			count = 0;
		}
		return null;
	}

}
