package com.spring.batch.step;

import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.data.RepositoryItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.spring.batch.model.Writer;
import com.spring.batch.repository.WriterRepository;

@Component
@StepScope
public class CWriter extends RepositoryItemWriter<Writer> {
	@Autowired
	private WriterRepository writerRepository;

	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		super.afterPropertiesSet();
	}
}
  