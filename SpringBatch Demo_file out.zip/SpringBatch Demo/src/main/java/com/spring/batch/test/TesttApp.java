package com.spring.batch.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.batch.config.BatchConfig;
import com.spring.batch.listner.JobCompletionListener;

public class TesttApp {

	public static void main(String[] args) {
		    ApplicationContext context = new ClassPathXmlApplicationContext("bean.xml");
		      HelloWorld obj = (HelloWorld) context.getBean("helloWorld");
		      obj.getMessage();

		
		  ApplicationContext ctx = new AnnotationConfigApplicationContext(HelloWorldConfig.class);
		   HelloWorld helloWorld = ctx.getBean(HelloWorld.class);
		   helloWorld.setMessage("Hello World!");
		   helloWorld.getMessage();
		   
		   
		   AnnotationConfigApplicationContext  batchCxt = new AnnotationConfigApplicationContext();
		   batchCxt.register(BatchConfig.class);
		  // batchCxt.register(AdditionalConfig.class);
		   //batchCxt.refresh();
		  
		   JobCompletionListener jobExecutionListener=batchCxt.getBean(JobCompletionListener.class);
		   System.out.println(jobExecutionListener);
		   // jobExecutionListener.afterJob(jobExecution);
		   
		   //RecordRepository recordRepository= batchCxt.getBean(RecordRepository.class);
		 // List<Record> records=recordRepository.findAll();
		 // System.out.println(records);
	}

}
