package com.spring.batch.step;

import java.util.List;

import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.PassThroughLineAggregator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Component;

import com.spring.batch.model.Writer;
import com.spring.batch.repository.WriterRepository;

@Component
@StepScope
public class RecordItemWriter extends FlatFileItemWriter<Writer> {
	@Autowired
	private WriterRepository writerRepository;

	/*@Override
	public void write(List<? extends Writer> items) throws Exception {
		//WriterRepository writerRepository=applicationContext.getBean(WriterRepository.class);
		System.out.println("-----WriterRepo"+writerRepository);
		
		items.forEach(item ->System.out.println(item.getFullName()+"::"+item.getId()));
		items.forEach(writer ->writerRepository.save(writer));
		
	
	}*/
@Override
public void afterPropertiesSet() throws Exception {
	setResource(new FileSystemResource("C:\\Users\\GP\\Downloads\\Projects\\Spring batch\\SpringBatch Demo\\src\\main\\resources\\text.txt"));
	setLineAggregator(new PassThroughLineAggregator<Writer>());
}

}
