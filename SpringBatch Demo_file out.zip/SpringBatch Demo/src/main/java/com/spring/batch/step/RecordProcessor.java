package com.spring.batch.step;

import org.springframework.batch.item.ItemProcessor;

import com.spring.batch.model.Record;
import com.spring.batch.model.Writer;

public class RecordProcessor implements ItemProcessor<Record, Writer> {

	@Override
	public Writer process(Record item) throws Exception {
		
		Writer writer=new Writer();
		writer.setFullName(item.getFirstName()+item.getLastName());
		writer.setId(item.getId());
		writer.setRandomNum(item.getRandomNum());
		return writer;
	}

}
