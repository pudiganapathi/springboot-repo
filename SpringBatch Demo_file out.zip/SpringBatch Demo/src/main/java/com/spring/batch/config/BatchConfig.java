package com.spring.batch.config;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.spring.batch.listner.JobCompletionListener;
import com.spring.batch.model.Record;
import com.spring.batch.model.Writer;
import com.spring.batch.step.RecordItemReader;
import com.spring.batch.step.RecordItemWriter;
import com.spring.batch.step.RecordProcessor;

@Configuration
@EnableBatchProcessing
public class BatchConfig {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	private ApplicationContext applicationContext;

	/*
	 * @Autowired private RecordItemReader recordItemReader;
	 * 
	 * @Autowired private RecordItemWriter recordItemWriter;
	 */
	@Bean
	public Job processJob() {

		return jobBuilderFactory.get("processJob").incrementer(new RunIdIncrementer()).listener(listener())
				.flow(step1()).end().build();
	}

	@Bean
	public Step step1() {
		RecordItemReader recordItemReader=applicationContext.getBean(RecordItemReader.class);
		RecordItemWriter recordItemWriter=applicationContext.getBean(RecordItemWriter.class);
		return stepBuilderFactory.get("step1").<Record, Writer>chunk(5).reader(recordItemReader)
				.processor(new RecordProcessor()).writer(recordItemWriter).build();
	}

	@Bean
	public JobExecutionListener listener() {
		return new JobCompletionListener();
	}

}
