var app = angular.module('myApp', []);
app.controller('focusCtlr', function($scope) {
    $scope.hasFocus=false;
    $scope.myFunc=function(entNm){
	console.log("updated Value--->"+entNm);	
	$('#user').focus();
	}
});