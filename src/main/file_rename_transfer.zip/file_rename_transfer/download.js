/**
 * Module dependencies.
 */

var express = require('../../');
var path = require('path');
var router = express.Router();
var fs = require('fs');

router.get('/', function(req, res){
  res.send('<ul>'
	+ '<li>Redirected to download Api</li>'
   // + '<li>Download <a href="/download/amazing.txt">output.txt</a>.</li>'
    + '</ul>');
});

// /files/* is accessed via req.params[0]
// but here we name it :file
router.get('/:file(*)', function(req, res, next){
  var filePath = path.join(__dirname, 'download', req.params.file);
  /*res.download(filePath, function (err) {
    if (!err) return; // file sent
    if (err && err.status !== 404) return next(err); // non-404 error
    // file for download not found
    res.statusCode = 404;
    res.send('Cant find that file, sorry!');
  });*/
  res.send('<ul>'
	+ '<li>Redirected to download file'+filePath
    + '</li></ul>')
});

module.exports = router;

