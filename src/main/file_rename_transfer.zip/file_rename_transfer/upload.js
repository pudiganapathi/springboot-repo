/**
 * Module dependencies.
 */

var express = require('../..');
var multiparty = require('multiparty');
var format = require('util').format;
var path = require('path');
var fs = require('fs');

var router = express.Router();

router.get('/',render() );


function render(){
	return function(request, response){
		//var url = request.url;
		var filename = 'output.txt';
			//url.substring(url.lastIndexOf('/')+1);
			//console.log('url: ' + url);
			console.log('filename: ' + filename);
			var newfilename=filename.replace(RegExp('$$', 'g'),'@!@#');;
			/*if (filename.match(/(\D+)\d+\.txt\.gz/)) {
				newfilename = RegExp.$1 + 'xml.gz';			
				console.log('newfilename: ' + newfilename);
			}
			var readStream = fs.createReadStream('./' + filename);
		    // We replaced all the event handlers with a simple call to readStream.pipe()
			response.writeHead(200, {'Content-Type': 'application/octet-stream',"Content-Disposition": "attachment; filename=" + filename}); 
		    readStream.pipe(response);*/
		    response.redirect("/download/"+newfilename);
			//res.format(obj);
  };
}
//export this router to use in our index.js
module.exports = router;
