var express = require('../../');
var app = express();

var upload = require('./upload.js');
var download = require('./download.js');

//both index.js and things.js should be in same directory
app.use('/upload', upload);
app.use('/download', download);
if (!module.parent) {
	app.listen(8000);
	console.log('Express started on port 8000');
}
