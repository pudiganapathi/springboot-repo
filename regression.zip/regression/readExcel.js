'use strict';

var fs = require('fs');
var _ = require('lodash');

var Excel = require('exceljs');

var HrStopwatch = require('./utils/hr-stopwatch');

process.argv = ['node', 'LONDENEHDC0_London_2_SAREA_Migration_Tracker_2018_05_23B.xlsx', 'londan2.xlsx']

var filename = process.argv[1];
var outputfilename=process.argv[2];
console.log('Input File name',filename);

var wb = new Excel.Workbook();

var stopwatch = new HrStopwatch();
stopwatch.start();
var column1=[];
// assuming file created by testBookOut
wb.xlsx.readFile(filename)
  .then(function() {
    var micros = stopwatch.microseconds;

    console.log('Loaded', filename);
    console.log('Time taken:', micros);

    var ws = wb.getWorksheet("010000");
var cell4= ws.getColumn('D');
    cell4.eachCell(function(cell, rowNumber) {
		column1.push(cell.value);
		if (rowNumber==2)
    console.log('Row ' + rowNumber + ' = ' + JSON.stringify(cell.value));
	});
	var Workbook = Excel.Workbook;
  var owb = new Workbook();
var ows = owb.addWorksheet("00_out");
ows.columns = [{ header: 'name', key: 'name', width: 10 }]
//console.log(column1);
ows.getColumn("name").values = column1;



  owb.xlsx.writeFile(outputfilename)
  .then(function(){
      });
	
    /*var column9 = ws.getColumn(9);

    var row2 = ws.getRow(2);
	console.log("second Row",row2);
	
	console.log(ws.getCell("A2").value);
    console.log(ws.getCell("B2").value); 
	console.log(ws.getCell("C2").value);*/
	
  });
  
	  
