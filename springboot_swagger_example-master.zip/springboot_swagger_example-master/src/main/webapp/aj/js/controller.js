app.controller('customersCtrl', function($scope, $http) {
	var self = $scope;
	self.addProduct = function() {
	};
});