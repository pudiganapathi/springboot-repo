function usernamevalidate(){
	
	var userName = document.getElementById("username").value;
	if(userName.length < 6){
		alert('Please enter User Name greater than 6 characters');
	}
}

function changeCountry(){

	var selectCountry = document.getElementById("selectCountry").value;
	if(selectCountry === "Ind"){
		alert('selected country is India');
	}else if(selectCountry === "USA"){
		alert('selected country is USA');
	}
}

function confirmPassword(){

	var password = document.getElementById("pwd").value;
	var confirmPasswrd = document.getElementById("confirmPwd").value;
	if((password.length !== confirmPasswrd.length) && (password.valueOf() !== confirmPasswrd.valueOf())){
		alert('passwords enterded are not matching');
	}
}

function maleSelection(){

	var maleSelected = document.getElementById("male").value;
	if(maleSelected){
		alert('gender selected is male');
	}
}

function femaleSelection(){

	var femaleSelected = document.getElementById("female").value;
	if(femaleSelected){
		alert('gender selected is female');
	}
}

function emailCheck(){

	var emailSelected = document.getElementById("email").value;
	if(!((emailSelected.includes("@")) && (emailSelected.includes(".com")))){
		alert('please enter a valid email id');
	}
}

function register(){

	var userName = document.getElementById("username").value;
	var password = document.getElementById("pwd").value;
	var confirmPasswrd = document.getElementById("confirmPwd").value;
	var emailSelected = document.getElementById("email").value;
	var maleSelected = document.getElementById("male").value;
	var femaleSelected = document.getElementById("female").value;
	var selectCountry = document.getElementById("selectCountry").value;
	var mobileNumber = document.getElementById("mobileNo").value;
	
	if(!userName || !selectCountry || !password || !confirmPasswrd || !maleSelected || !emailSelected || !femaleSelected || !mobileNumber){
		
		alert('please completely fill all the boxes for registration');
	}
}






